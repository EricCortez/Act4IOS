import Cocoa

var str = "Act 4"


var arreglo = [3,6,9,2,4,1]

for menor in arreglo{
  if menor<5{
    print(menor,"elemento menor a 5")
  }
}

var resultado = 0
func suma(a:Int, b:Int)-> Int{
    resultado = a + b;
    return resultado
}

 print("Suma es :",suma(a:10,b:99))


func potencia(a:Int, b:Int)-> Int{
  
    var x:Int=1
    for _ in 1...b{
    x=x*a
        print(x)
        }
    return x
}
print( potencia(a:3,b:3 )," potencia " )


enum meses {
       case Enero
       case Febrero
       case Marzo
       case Abril
       case Mayo
       case Junio
       case Julio
       case Agosto
       case Septiembre
       case Octubre
       case Noviembre
       case Diciembre
}

func numeroMes(meses:meses)-> meses{
   
 switch meses{
 case .Enero:
        print(1)
 case .Febrero:
        print(2)
 case .Marzo:
        print(3)
 case .Abril:
        print(4)
 case .Mayo:
        print(5)
 case .Junio:
        print(6)
 case .Julio:
        print(7)
 case .Agosto:
        print(8)
 case .Septiembre:
        print(9)
 case .Octubre:
        print(10)
 case .Noviembre:
        print(11)
 case .Diciembre:
        print(12)
  }
    return meses
}
var mes:meses = .Octubre
print("Mes en numero: ",numeroMes(meses:mes))

